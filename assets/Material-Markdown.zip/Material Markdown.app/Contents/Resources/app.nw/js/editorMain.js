var editorModule = angular.module("editorModule", ["ngMaterial", 'DWand.nw-fileDialog', 'ngMdIcons']);

editorModule.factory("Editor", function(){
    var editor = new EpicEditor({
        container: "epiceditor",
        textarea: "data",
        clientSideStorage: true,
        localStorageName: 'epiceditor',
        useNativeFullscreen: false,
        parser: marked,
        basePath: "EpicEditor/epiceditor",
        theme: {
            base: '/themes/base/epiceditor.css',
            preview: '/themes/preview/github.css',
            editor: '/themes/editor/epic-dark.css'
        },
        button: {
            preview: true,
            fullscreen: true,
            bar: "auto"
        },
        focusOnLoad: false,
        shortcut: {
            modifier: 18,
            fullscreen: 70,
            preview: 80
        },
        string: {
            togglePreview: 'Toggle Preview Mode',
            toggleEdit: 'Toggle Edit Mode',
            toggleFullscreen: 'Enter Fullscreen'
        },
        autogrow: false
    });

    return{
        theEditor: editor,
        load: function(){
            editor.load(function(){
                editor.enterFullscreen();
            });
        },
        open: function(file){
            editor.open(file);
        },
        importFile: function(file, text){
            editor.importFile(file, text);
        }
    }
});

//Loading the editor

editorModule.run(["Editor", function(Editor){
    Editor.load();
}]);
