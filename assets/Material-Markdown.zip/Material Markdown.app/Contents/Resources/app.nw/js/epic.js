var editor = new EpicEditor({
  container: "epiceditor",
  useNativeFullscreen: false,
  theme: {
    base: 'https://cdnjs.cloudflare.com/ajax/libs/epiceditor/0.2.2/themes/base/epiceditor.css',
    preview: 'http://cdnjs.cloudflare.com/ajax/libs/epiceditor/0.2.2/themes/preview/github.css',
    editor: 'https://cdnjs.cloudflare.com/ajax/libs/epiceditor/0.2.2/themes/editor/epic-dark.css'
  },
  button: {
    preview: true,
    fullscreen: true,
    bar: "show"
  }
})

editor.load(function(){
    editor.enterFullscreen();
});
