# Material Markdown

![Material Markdown](assets/Material-Markdown-banner.png)

Material Markdown is an open-source markdown editor for Mac build using [nw.js](http://nwjs.io),  [Epic Editor](http://epiceditor.com/) and [Angular Material](https://material.angularjs.org/#/). Feel free to contribue and improve the editor, right now the functionality is pretty basic (the project is quite young).

##TODO
- ~~Add HTML and PDF export~~
- Add ability to modify themes for editor and previewer
- Add ability to control font size
- Add copy/paste support (for some reason quite difficult when using node webkit and a third party editing area).
- Continue the awesome

