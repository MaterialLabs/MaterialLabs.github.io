var editorModule = angular.module("editorModule", ["ngMaterial", 'DWand.nw-fileDialog', 'ngMdIcons']);

editorModule.factory("Editor", function(){

    return{
        theEditor: editor,
        load: function(){
            editor.load(function(){
                editor.enterFullscreen();
            });
        },
        open: function(file){
            editor.open(file);
        },
        importFile: function(file, text){
            editor.importFile(file, text);
        }
    };
});
