var editor = new EpicEditor({
    container: "epiceditor",
    textarea: "data",
    clientSideStorage: true,
    localStorageName: 'epiceditor',
    useNativeFullscreen: false,
    parser: marked,
    basePath: "EpicEditor/epiceditor",
    theme: {
        base: '/themes/base/epiceditor.css',
        preview: '/themes/preview/github.css',
        editor: '/themes/editor/epic-dark.css'
    },
    button: {
        preview: true,
        fullscreen: true,
        bar: "auto"
    },
    focusOnLoad: false,
    string: {
        togglePreview: 'Toggle Preview Mode',
        toggleEdit: 'Toggle Edit Mode',
        toggleFullscreen: 'Enter Fullscreen'
    },
    autogrow: false
});

editor.load(function(){
    editor.enterFullscreen();
});
