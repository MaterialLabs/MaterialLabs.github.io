var app = angular.module("Material-Markdown", ["ngMaterial", 'DWand.nw-fileDialog', 'ngMdIcons', "editorModule"]);

app.controller("editorCtrl", function($scope){

});

app.factory("currentWorkingFile", function(){
    var currentWorkingFile = "";
    return{
        setWorkingFile: function(file){
            currentWorkingFile = file;
        },
        getWorkingFile: function(){
            return currentWorkingFile;
        }
    }
});

app.factory('GUI', function() {
    return require('nw.gui');
});

app.factory('Window', ['GUI', function(gui) {
    return gui.Window.get();
}]);

app.factory('Clipboard', ['GUI', function(gui) {
    return gui.Clipboard.get();
}]);

app.factory('FS', function() {
    return require('fs');
});

app.factory("Markdown", function(){
    return require( "markdown" ).markdown;
});

app.factory("MarkdownPDF", function(){
    return require("markdown-pdf");
})

//SETTING THE ORANGE THEME

app.config(function($mdThemingProvider) {
  $mdThemingProvider.theme('default')
    .primaryPalette('deep-orange')
    .accentPalette('purple');
});

app.run(['GUI', 'Window', 'Clipboard', 'fileDialog', 'Editor', 'FS', "Markdown", "MarkdownPDF",
    "currentWorkingFile", function(GUI, Window, Clipboard, fileDialog,
        Editor, FS, Markdown, MarkdownPDF, currentWorkingFile) {

    //==================================================================================
                                //MAKING THE MENUS
    //==================================================================================

    var windowMenu = new GUI.Menu({
        type: 'menubar'
    });

    var appMenu = new GUI.Menu();

    //Add to window menu
    windowMenu.append(new GUI.MenuItem({
        label: "Material Editor",
        submenu: appMenu
    }));

    appMenu.append(new GUI.MenuItem({
        label: "About",
        click: function(){
            alert("This is a lightweight Material Design Code Editor");
        }
    }));

    appMenu.append(new GUI.MenuItem({
        label: "Preferences",
        click: function(){
            alert("Preferences biyatch");
        }
    }));

    //================================File menu===================================
    var fileMenu = new GUI.Menu();

    //Add to window menu
    windowMenu.append(new GUI.MenuItem({
        label: "File",
        submenu: fileMenu
    }));

    //About subentries
    fileMenu.append(new GUI.MenuItem({
        label: "New",
        click: function(){

        },
        key: "n",
        modifiers: "cmd"
    }));

    fileMenu.append(new GUI.MenuItem({
        label: "Open",
        click: function(){
            fileDialog.openFile(function(filename){
                currentWorkingFile.setWorkingFile(filename);
                FS.readFile(filename, function (err, data){
                    if (err){
                        throw err;
                    }else{
                        Editor.theEditor.importFile(filename, data.toString());
                    }
                });
            }, false, ["txt", "md", "markdown"]);

        },
        key: "o",
        modifiers: "cmd"
    }));

    fileMenu.append(new GUI.MenuItem({
        label: "New Window",
        click: function(){
            //put something here
        },
        key: "n",
        modifiers: "cmd-shift"
    }));

    fileMenu.append(new GUI.MenuItem({
        label: "Print",
        click: function(){
            alert("Printing");
        },
        key: "p",
        modifiers: "cmd"
    }));

    // EXPORT MENU STRUCTURE

    var exportMenu = new GUI.Menu();

    // Add some items
    exportMenu.append(new GUI.MenuItem({
        label: 'HTML',
        click: function(){
            var str = localStorage.getItem("epiceditor");
            var json = JSON.parse(str);
            var content = json.epiceditor.content;
            var html = Markdown.toHTML(content);
            var filetypes = [".html"];
            var defaultFilename = "file.html";
            fileDialog.saveAs(function(filename, defaultFilename, filetypes){
                FS.writeFile(filename, html, function (err) {
                  if (err) {
                      alert("Write failed: " + err);
                    return;
                  }
                  return;
                });
            });
        }
    }));

    exportMenu.append(new GUI.MenuItem({
        label: 'PDF',
        click: function(){
            var str = localStorage.getItem("epiceditor");
            var json = JSON.parse(str);
            var content = json.epiceditor.content;
            fileDialog.saveAs(function(filename){
                MarkdownPDF({
                    paperBorder: "2cm",
                    cssPath: "node_modules/markdown-pdf/css/github.css"
                }).from.string(content).to(filename + ".pdf", function () {
                  console.log("Done");
                })
            });
        }
    }));

    fileMenu.append(new GUI.MenuItem({
        label: "Export As",
        submenu: exportMenu
    }));

    //separator

    fileMenu.append(new GUI.MenuItem({
        type: "separator"
    }));

    fileMenu.append(new GUI.MenuItem({
        label: "Save",
        click: function(){
            fileDialog.saveAs(function(filename){
                currentWorkingFile.setWorkingFile(filename);
                var str = localStorage.getItem("epiceditor");
                var json = JSON.parse(str);
                var content = json.epiceditor.content;
                FS.writeFile(filename, content, function (err) {
                  if (err) {
                    alert("Write failed: " + err);
                    return;
                  }
                  return;
                });
            });
        },
        key: "s",
        modifiers: "cmd"
    }));

    fileMenu.append(new GUI.MenuItem({
        label: "Save As",
        click: function(){
            alert("Save As");
        },
        key: "s",
        modifiers: "cmd-shift"
    }));

    //separator

    fileMenu.append(new GUI.MenuItem({
        type: "separator"
    }));


    fileMenu.append(new GUI.MenuItem({
        label: "Close Tab",
        click: function(){
            alert("Close Tab");
        }
    }));

    fileMenu.append(new GUI.MenuItem({
        label: "Close Material Markdown",
        click: function(){
            Window.close();
        },
        key: "q",
        modifiers: "cmd"
    }));

    //===========================EDIT MENU===========================

    var editMenu = new GUI.Menu();

    //Add to window menu
    windowMenu.append(new GUI.MenuItem({
        label: "Edit",
        submenu: editMenu,
    }));


    editMenu.append(new GUI.MenuItem({
        label: "Copy HTML",
        click: function(){
            var str = localStorage.getItem("epiceditor");
            var json = JSON.parse(str);
            var content = json.epiceditor.content;
            var html = Markdown.toHTML(content);
            Clipboard.set(html);
        },
        key: "c",
        modifiers: "cmd"
    }));


    //==============================VIEW===============================

    var viewMenu = new GUI.Menu();

    //Add to window menu
    windowMenu.append(new GUI.MenuItem({
        label: "View",
        submenu: viewMenu,
    }));

    //About subentries
    viewMenu.append(new GUI.MenuItem({
        label: "Toggle Wrap Line",
        type: "checkbox",
        checked: function(){
            //REMOVE THAT DAMN LINE
            alert("the line is enabled");
        }
    }));

    //===========================WINDOW MENU===========================

    var windowMen = new GUI.Menu();

    //Add to window menu
    windowMenu.append(new GUI.MenuItem({
        label: "Window",
        submenu: windowMen,
    }));

    //subentries
    windowMen.append(new GUI.MenuItem({
        label: "Bring all to Front",
        click: function(){
            alert("bring all to front");
        }
    }));

    //Assigning to the window
    Window.menu = windowMenu;

    //-----------------------HEADER BUTTONS------------------------

    var minimize = document.getElementById('minimize');
    var close = document.getElementById('close');
    var maximize = document.getElementById('maximize');

    if (minimize){
        minimize.addEventListener("click", function(){
            Window.minimize();
        }, false);
    }

    if (close){
        close.addEventListener("click", function(){
            Window.close();
        }, false);
    }

    //should change value of icon from fullscreen to fullscreen-exit on window state change

    if (maximize){
        maximize.addEventListener("click", function(){
            Window.toggleFullscreen()
        }, false);
    }

}]);
